
Masjid Farhat Habeeb - Website (v7 Final)

This package includes:
- Verse of the Day with Arabic + English + Urdu and Tafseer attempt (AlQuran Cloud)
- Geolocation-based Prayer Times (Aladhan API) with fallback to Chandrayangutta, Hyderabad
- Islamic (Hijri) calendar monthly view with today's Hijri date highlighted
- Refresh buttons for Prayer Times and Verse
- Auto light/dark mode switching at Maghrib (with manual override)
- Modern font set: Cairo/Inter/Lateef/Roboto Mono (via Google Fonts)

Notes:
- Tafseer: public APIs sometimes don't provide full authoritative tafsir text. The site attempts to fetch tafsir; if not available, a placeholder expanded tafsir is shown. To include full Ibn Kathir or other tafsir texts, replace the tafseer placeholder in js/main.js or integrate a tafsir data source.
- All API calls are client-side (Aladhan and AlQuran Cloud). If your hosting blocks these calls, proxy server-side.
- Replace placeholder images/audio in assets/ with real media.
- Replace Formspree endpoint in contact.html with your real endpoint after signup.

Deploy:
1. Unzip and inspect files.
2. Replace placeholders and deploy to Netlify or GitHub Pages.
